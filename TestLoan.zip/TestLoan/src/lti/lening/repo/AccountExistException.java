package lti.lening.repo;

public class AccountExistException extends Exception {

	public AccountExistException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
