package lti.lening.test;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import lti.lening.bean.AadhaarPanBean;
import lti.lening.bean.RegisterBean;
import lti.lening.repo.AccountExistException;
import lti.lening.service.LoanServiceImpl;

public class TestAadhaar {

	@Test
	public void testAadhaarNoSuccess() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		RegisterBean apb = new RegisterBean();
		apb.setAadhaarNo("445263214569");
		try {
			AadhaarPanBean bean = service.aadhaarAuthenticate(apb);

		} catch (AccountExistException e) {
			e.printStackTrace();
		}
	}

	@Test(expected = IndexOutOfBoundsException.class)

	public void testAadhaarNoFailure() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		RegisterBean apb = new RegisterBean();
		apb.setAadhaarNo("8989895656");
		try {
			AadhaarPanBean bean = service.aadhaarAuthenticate(apb);

		} catch (AccountExistException e) {

			e.printStackTrace();
		}
	}
} 