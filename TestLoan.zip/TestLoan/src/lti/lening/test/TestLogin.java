package lti.lening.test;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import lti.lening.bean.AadhaarPanBean;
import lti.lening.bean.LoginBean;
import lti.lening.bean.RegisterBean;
import lti.lening.service.LoanServiceImpl;

public class TestLogin {
	@Test
	public void testLoginSuccess() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		LoginBean lb = new LoginBean();
		lb.setEmail("emily@gmail.com");
		lb.setPassword("1234");

		RegisterBean bean = service.authenticate(lb);
		
		System.out.println(bean.getAadhaarNo());
		System.out.println(bean.getPanNo());
		
	}

	@Test(expected = NullPointerException.class)
	public void testLoginFail1() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		LoginBean lb = new LoginBean();
		lb.setEmail("emily1@gmail.com");
		lb.setPassword("Emily@1234");
		;
		RegisterBean bean = service.authenticate(lb);

		System.out.println(bean.getAadhaarNo());
		System.out.println(bean.getPanNo());
	}

	@Test(expected = NullPointerException.class)
	public void testLoginFail2() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		LoginBean lb = new LoginBean();
		lb.setEmail("emily@gmail.com");
		lb.setPassword("Emily@12354");
		;
		RegisterBean bean = service.authenticate(lb);

		System.out.println(bean.getAadhaarNo());
		System.out.println(bean.getPanNo());
	}

	@Test(expected = NullPointerException.class)
	public void testLoginFail3() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		LoginBean lb = new LoginBean();
		lb.setEmail("emily1@gmail.com");
		lb.setPassword("Emily@123");
		;
		RegisterBean bean = service.authenticate(lb);

		System.out.println(bean.getAadhaarNo());
		System.out.println(bean.getPanNo());
	}

}
