package lti.lening.test;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import lti.lening.bean.ForgetBean;
import lti.lening.service.LoanServiceImpl;

public class TestForgotPassword {
	@Test
	public void testLoginSuccess() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		ForgetBean fb = new ForgetBean();
		fb.setEmail("emily@gmail.com");
		fb.setAadhaarNo("445263214569");
		fb.setPassword("Emily@123");
		fb.setConfirmPassword("Emily@123");
		boolean bean = service.resetPassword(fb);
		System.out.println(true);
	}

	
	@Test
	public void testLoginFail1() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		ForgetBean fb = new ForgetBean();
		fb.setEmail("emily@gmail.com");
		fb.setAadhaarNo("445263214569");
		fb.setPassword("123");
		fb.setConfirmPassword("1234");
		boolean bean = service.resetPassword(fb);
		System.out.println(false);
	}

	@Test
	public void testLoginFail2() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		ForgetBean fb = new ForgetBean();
		fb.setEmail("emily1@gmail.com");
		fb.setAadhaarNo("445263214569");
		fb.setPassword("123");
		fb.setConfirmPassword("1234");
		boolean bean = service.resetPassword(fb);
		System.out.println(false);
	}

	@Test
	public void testLoginFail3() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		ForgetBean fb = new ForgetBean();
		fb.setEmail("emily@gmail.com");
		fb.setAadhaarNo("445263214569");
		fb.setPassword("1234");
		fb.setConfirmPassword("123");
		boolean bean = service.resetPassword(fb);
		System.out.println(false);
	}
}