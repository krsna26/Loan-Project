package lti.lening.test;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import lti.lening.bean.FourWheelerVehicleBean;
import lti.lening.bean.TwoWheelerVehicleBean;
import lti.lening.service.LoanServiceImpl;

public class TestType {
	@Test

	public void testTwoWheelerTypeSuccess() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		TwoWheelerVehicleBean twvb = new TwoWheelerVehicleBean();
		twvb.setBrand("twowheeler");
		int size = (service.getWheelerBrands(twvb.getBrand()).size());

		System.out.println(size);

	}

	@Test
	public void testFourWheelerTpeSuccess() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		LoanServiceImpl service = (LoanServiceImpl) ctx.getBean("service");

		FourWheelerVehicleBean fwvb = new FourWheelerVehicleBean();
		fwvb.setBrand("fourwheeler");
		int size = (service.getWheelerBrands(fwvb.getBrand()).size());

		System.out.println(size);
	}
}
